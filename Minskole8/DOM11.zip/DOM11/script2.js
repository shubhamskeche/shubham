
let ulList = document.querySelector('ul')

let liList = document.querySelectorAll('li')   // [] nodeList -----> array

console.log(liList)



// program One

// console.log(ulList)

// ulList.addEventListener('mouseover',function(){

//     ulList.textContent = ulList.textContent.toUpperCase()

// })

// ulList.addEventListener('mouseout',function(){

//     ulList.textContent = ulList.textContent.toLowerCase()

// })

//program 2

// ulList.addEventListener('mouseover',()=>{
//     for(let i = 0 ; i < liList.length ;i++){
//             liList[i].textContent =  liList[i].textContent.toUpperCase()
//     }

// })

// ulList.addEventListener('mouseout',()=>{
//     for(let i = 0 ; i < liList.length ;i++){
//             liList[i].textContent =  liList[i].textContent.toLowerCase()
//     }

// })














// <h1>Hello<h1>

// let rrr = document.querySelector('h1')
// rrr.textContent